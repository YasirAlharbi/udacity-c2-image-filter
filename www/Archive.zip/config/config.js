"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = {
    "dev": {
        "username": "udagramyasirdev",
        "password": "udagramyasirdev",
        "database": "udagramyasirdev",
        "host": "udagramyasirdev.cowxeopexn6q.us-east-2.rds.amazonaws.com",
        "dialect": "postgres",
        "aws_reigion": "us-east-2",
        "aws_profile": "default",
        "aws_media_bucket": "udagram-yasir-dev"
    },
    "prod": {
        "username": "",
        "password": "",
        "database": "udagram_prod",
        "host": "",
        "dialect": "postgres"
    }
};
//# sourceMappingURL=config.js.map